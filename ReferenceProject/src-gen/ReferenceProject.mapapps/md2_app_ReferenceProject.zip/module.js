define([
    "ct/Stateful",
    "./contentproviders/ComplaintProvider",
    "./Controller",
    "./CustomActions",
    "./Models"
], {});
