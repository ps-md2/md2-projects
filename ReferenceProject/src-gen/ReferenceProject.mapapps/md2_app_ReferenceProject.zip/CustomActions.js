define([
    "dojo/_base/declare",
    "./actions/StartAction",
    "./actions/__startupAction"
],
function(
    declare,
    startAction,
    __startupAction
) {
    
    return declare([], {
        
        /**
         * Provide an array with instances of all actions.
         */
        createInstance: function() {
            return [
                new startAction(),
                new __startupAction()
            ];
        }
        
    });
});
