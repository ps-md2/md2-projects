define([
    "dojo/_base/declare",
    "md2_runtime/actions/_Action"
],
function(declare, _Action) {
    
    return declare([_Action], {
        
        _actionSignature: "__startupAction",
        
        execute: function() {
            
            var action0j = this.$.actionFactory.getGotoViewAction("firstView");
            action0j.execute();
            
            var action0k = this.$.actionFactory.getCustomAction("startAction");
            action0k.execute();
            
        }
        
    });
});
