define([
    "dojo/_base/declare"
],
function(declare) {
    
    return declare([], {
        
        /**
         * Provide an array with instances of all model elements (entities and enums).
         */
        createInstance: function() {
            return [
            ];
        }
        
    });
});
